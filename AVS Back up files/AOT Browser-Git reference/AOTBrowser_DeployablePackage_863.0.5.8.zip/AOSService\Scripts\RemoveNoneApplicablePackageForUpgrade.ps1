﻿
$blockListedPackage = (
"dynamicsax-appfoundationtestcommon",
"dynamicsax-appfoundationtestcommon-compile",
"dynamicsax-appfoundationtestcommon-develop",
"dynamicsax-appfoundationtestcommon-formadaptor",
"dynamicsax-application-applicationruntime",
"dynamicsax-applicationfoundation-compile",
"dynamicsax-applicationfoundation-develop",
"dynamicsax-applicationfoundation-formadaptor",
"dynamicsax-applicationfoundationformadaptor-compile",
"dynamicsax-applicationfoundationformadaptor-develop",
"dynamicsax-applicationfoundationformadaptor-formadaptor",
"dynamicsax-applicationfoundationunittests",
"dynamicsax-applicationfoundationunittests-compile",
"dynamicsax-applicationfoundationunittests-develop",
"dynamicsax-applicationfoundationunittests-formadaptor",
"dynamicsax-applicationplatform-compile",
"dynamicsax-applicationplatform-develop",
"dynamicsax-applicationplatform-formadaptor",
"dynamicsax-applicationplatformformadaptor-compile",
"dynamicsax-applicationplatformformadaptor-develop",
"dynamicsax-applicationplatformformadaptor-formadaptor",
"dynamicsax-applicationstaging",
"dynamicsax-applicationstaging-compile",
"dynamicsax-applicationstaging-develop",
"dynamicsax-applicationstagingformadaptor",
"dynamicsax-applicationstaging-formadaptor",
"dynamicsax-applicationstagingformadaptor-compile",
"dynamicsax-applicationstagingformadaptor-develop",
"dynamicsax-applicationstagingformadaptor-formadaptor",
"dynamicsax-applicationstagingtests",
"dynamicsax-applicationstagingtests-compile",
"dynamicsax-applicationstagingtests-develop",
"dynamicsax-applicationstagingtests-formadaptor",
"dynamicsax-applicationsuite-compile",
"dynamicsax-applicationsuite-develop",
"dynamicsax-applicationsuite-formadaptor",
"dynamicsax-applicationsuiteformadaptor-compile",
"dynamicsax-applicationsuiteformadaptor-develop",
"dynamicsax-applicationsuiteformadaptor-formadaptor",
"dynamicsax-applicationworkspaces-compile",
"dynamicsax-applicationworkspaces-develop",
"dynamicsax-applicationworkspacesformadaptor",
"dynamicsax-applicationworkspaces-formadaptor",
"dynamicsax-applicationworkspacesformadaptor-compile",
"dynamicsax-applicationworkspacesformadaptor-develop",
"dynamicsax-applicationworkspacesformadaptor-formadaptor",
"dynamicsax-applicationworkspacestests",
"dynamicsax-applicationworkspacestests-compile",
"dynamicsax-applicationworkspacestests-develop",
"dynamicsax-applicationworkspacestests-formadaptor",
"dynamicsax-appplatformtestcommon",
"dynamicsax-appplatformtestcommon-compile",
"dynamicsax-appplatformtestcommon-develop",
"dynamicsax-appplatformtestcommon-formadaptor",
"dynamicsax-appsuitetestcommon",
"dynamicsax-appsuitetestcommon-compile",
"dynamicsax-appsuitetestcommon-develop",
"dynamicsax-appsuitetestcommon-formadaptor",
"dynamicsax-budgetstaging",
"dynamicsax-budgetstaging-compile",
"dynamicsax-budgetstaging-develop",
"dynamicsax-budgetstagingformadaptor",
"dynamicsax-budgetstaging-formadaptor",
"dynamicsax-budgetstagingformadaptor-compile",
"dynamicsax-budgetstagingformadaptor-develop",
"dynamicsax-budgetstagingformadaptor-formadaptor",
"dynamicsax-budgetstagingtests",
"dynamicsax-budgetstagingtests-compile",
"dynamicsax-budgetstagingtests-develop",
"dynamicsax-budgetstagingtests-formadaptor",
"dynamicsax-calendar-compile",
"dynamicsax-calendar-develop",
"dynamicsax-calendarformadaptor",
"dynamicsax-calendar-formadaptor",
"dynamicsax-calendarformadaptor-compile",
"dynamicsax-calendarformadaptor-develop",
"dynamicsax-calendarformadaptor-formadaptor",
"dynamicsax-calendartests",
"dynamicsax-calendartests-compile",
"dynamicsax-calendartests-develop",
"dynamicsax-calendartests-formadaptor",
"dynamicsax-cirfoundationtests",
"dynamicsax-cirfoundationtests-compile",
"dynamicsax-cirfoundationtests-develop",
"dynamicsax-cirfoundationtests-formadaptor",
"dynamicsax-costaccounting",
"dynamicsax-costaccounting-compile",
"dynamicsax-costaccounting-develop",
"dynamicsax-costaccounting-formadaptor",
"dynamicsax-costaccountingformadaptor",
"dynamicsax-costaccountingformadaptor-compile",
"dynamicsax-costaccountingformadaptor-develop",
"dynamicsax-costaccountingformadaptor-formadaptor",
"dynamicsax-costaccountingtests",
"dynamicsax-costaccountingtests-compile",
"dynamicsax-costaccountingtests-develop",
"dynamicsax-costaccountingtests-formadaptor",
"dynamicsax-costaccountingax",
"dynamicsax-costaccountingax-compile",
"dynamicsax-costaccountingax-develop",
"dynamicsax-costaccountingax-formadaptor",
"dynamicsax-costaccountingaxformadaptor",
"dynamicsax-costaccountingaxformadaptor-compile",
"dynamicsax-costaccountingaxformadaptor-develop",
"dynamicsax-costaccountingaxformadaptor-formadaptor",
"dynamicsax-costaccountingaxtests",
"dynamicsax-costaccountingaxtests-compile",
"dynamicsax-costaccountingaxtests-develop",
"dynamicsax-costaccountingaxtests-formadaptor",
"dynamicsax-currency-compile",
"dynamicsax-currency-develop",
"dynamicsax-currencyformadaptor",
"dynamicsax-currency-formadaptor",
"dynamicsax-currencyformadaptor-compile",
"dynamicsax-currencyformadaptor-develop",
"dynamicsax-currencyformadaptor-formadaptor",
"dynamicsax-customeracceptancetests-compile",
"dynamicsax-customeracceptancetests-develop",
"dynamicsax-customeracceptancetests-formadaptor",
"dynamicsax-data-contoso",
"dynamicsax-data-demodata",
"dynamicsax-data-demovolumedata",
"dynamicsax-data-empty",
"dynamicsax-data-empty-platform",
"dynamicsax-dataimpexpapplication-compile",
"dynamicsax-dataimpexpapplication-develop",
"dynamicsax-dataimpexpapplication-formadaptor",
"dynamicsax-demodatasuite",
"dynamicsax-demodatasuite-compile",
"dynamicsax-demodatasuite-develop",
"dynamicsax-demodatasuite-formadaptor",
"dynamicsax-devtoolscustomizations",
"dynamicsax-devtoolscustomizations2",
"dynamicsax-devtoolscustomizations2-compile",
"dynamicsax-devtoolscustomizations2-develop",
"dynamicsax-devtoolscustomizations2-formadaptor",
"dynamicsax-devtoolscustomizations-compile",
"dynamicsax-devtoolscustomizations-develop",
"dynamicsax-devtoolscustomizations-formadaptor",
"dynamicsax-devtoolstestmodel",
"dynamicsax-devtoolstestmodel2",
"dynamicsax-devtoolstestmodel2-compile",
"dynamicsax-devtoolstestmodel2-develop",
"dynamicsax-devtoolstestmodel2-formadaptor",
"dynamicsax-devtoolstestmodel-compile",
"dynamicsax-devtoolstestmodel-develop",
"dynamicsax-devtoolstestmodel-formadaptor",
"dynamicsax-dimensions-compile",
"dynamicsax-dimensions-develop",
"dynamicsax-dimensionsformadaptor",
"dynamicsax-dimensions-formadaptor",
"dynamicsax-dimensionsformadaptor-compile",
"dynamicsax-dimensionsformadaptor-develop",
"dynamicsax-dimensionsformadaptor-formadaptor",
"dynamicsax-dimensionstestcommon",
"dynamicsax-dimensionstestcommon-compile",
"dynamicsax-dimensionstestcommon-develop",
"dynamicsax-dimensionstestcommon-formadaptor",
"dynamicsax-dimensionstests",
"dynamicsax-dimensionstests-compile",
"dynamicsax-dimensionstests-develop",
"dynamicsax-dimensionstests-formadaptor",
"dynamicsax-directory-compile",
"dynamicsax-directory-develop",
"dynamicsax-directory-formadaptor",
"dynamicsax-directoryformadaptor-compile",
"dynamicsax-directoryformadaptor-develop",
"dynamicsax-directoryformadaptor-formadaptor",
"dynamicsax-directorytests",
"dynamicsax-directorytests-compile",
"dynamicsax-directorytests-develop",
"dynamicsax-directorytests-formadaptor",
"dynamicsax-dispatchservice",
"dynamicsax-electronicreporting-compile",
"dynamicsax-electronicreporting-develop",
"dynamicsax-electronicreporting-formadaptor",
"dynamicsax-electronicreportingtestcommon",
"dynamicsax-electronicreportingtestcommon-compile",
"dynamicsax-electronicreportingtestcommon-develop",
"dynamicsax-electronicreportingtestcommon-formadaptor",
"dynamicsax-electronicreportingtests",
"dynamicsax-electronicreportingtests-compile",
"dynamicsax-electronicreportingtests-develop",
"dynamicsax-electronicreportingtests-formadaptor",
"dynamicsax-financialaccountingworkload",
"dynamicsax-financialaccountingworkload-compile",
"dynamicsax-financialaccountingworkload-develop",
"dynamicsax-financialaccountingworkload-formadaptor",
"dynamicsax-financialaccounting",
"dynamicsax-financialaccounting-compile",
"dynamicsax-financialaccounting-develop",
"dynamicsax-financialaccounting-formadaptor",
"dynamicsax-financialreportingadaptors",
"dynamicsax-financialreportingadaptors-compile",
"dynamicsax-financialreportingadaptors-develop",
"dynamicsax-financialreportingadaptors-formadaptor",
"dynamicsax-financialreporting-compile",
"dynamicsax-financialreporting-develop",
"dynamicsax-financialreporting-formadaptor",
"dynamicsax-financialreportingtestcommon",
"dynamicsax-financialreportingtestcommon-compile",
"dynamicsax-financialreportingtestcommon-develop",
"dynamicsax-financialreportingtestcommon-formadaptor",
"dynamicsax-financialreportingtests",
"dynamicsax-financialreportingtests-compile",
"dynamicsax-financialreportingtests-develop",
"dynamicsax-financialreportingtests-formadaptor",
"dynamicsax-fiscalbooks-compile",
"dynamicsax-fiscalbooks-develop",
"dynamicsax-fiscalbooksformadaptor",
"dynamicsax-fiscalbooks-formadaptor",
"dynamicsax-fiscalbooksformadaptor-compile",
"dynamicsax-fiscalbooksformadaptor-develop",
"dynamicsax-fiscalbooksformadaptor-formadaptor",
"dynamicsax-fiscalbookstests",
"dynamicsax-fiscalbookstests-compile",
"dynamicsax-fiscalbookstests-develop",
"dynamicsax-fiscalbookstests-formadaptor",
"dynamicsax-fleetmanagement-compile",
"dynamicsax-fleetmanagement-develop",
"dynamicsax-fleetmanagementextension-compile",
"dynamicsax-fleetmanagementextension-develop",
"dynamicsax-fleetmanagementextension-formadaptor",
"dynamicsax-fleetmanagement-formadaptor",
"dynamicsax-fleetmanagementunittests-compile",
"dynamicsax-fleetmanagementunittests-develop",
"dynamicsax-fleetmanagementunittests-formadaptor",
"dynamicsax-foundationtest",
"dynamicsax-foundationtestcommon",
"dynamicsax-foundationtestcommon-compile",
"dynamicsax-foundationtestcommon-develop",
"dynamicsax-foundationtestcommon-formadaptor",
"dynamicsax-foundationtest-compile",
"dynamicsax-foundationtest-develop",
"dynamicsax-foundationtest-formadaptor",
"dynamicsax-generalledger-compile",
"dynamicsax-generalledger-develop",
"dynamicsax-generalledgerformadaptor",
"dynamicsax-generalledger-formadaptor",
"dynamicsax-generalledgerformadaptor-compile",
"dynamicsax-generalledgerformadaptor-develop",
"dynamicsax-generalledgerformadaptor-formadaptor",
"dynamicsax-generalledgertests",
"dynamicsax-generalledgertests-compile",
"dynamicsax-generalledgertests-develop",
"dynamicsax-generalledgertests-formadaptor",
"dynamicsax-gfmtests",
"dynamicsax-gfmtests-compile",
"dynamicsax-gfmtests-develop",
"dynamicsax-gfmtests-formadaptor",
"dynamicsax-hcmtests",
"dynamicsax-hcmtests-compile",
"dynamicsax-hcmtests-develop",
"dynamicsax-hcmtests-formadaptor",
"dynamicsax-ledger-compile",
"dynamicsax-ledger-develop",
"dynamicsax-ledger-formadaptor",
"dynamicsax-ledgerformadaptor-compile",
"dynamicsax-ledgerformadaptor-develop",
"dynamicsax-ledgerformadaptor-formadaptor",
"dynamicsax-ledgertests",
"dynamicsax-ledgertests-compile",
"dynamicsax-ledgertests-develop",
"dynamicsax-ledgertests-formadaptor",
"dynamicsax-measurement-compile",
"dynamicsax-measurement-develop",
"dynamicsax-measurementformadaptor",
"dynamicsax-measurement-formadaptor",
"dynamicsax-measurementformadaptor-compile",
"dynamicsax-measurementformadaptor-develop",
"dynamicsax-measurementformadaptor-formadaptor",
"dynamicsax-measurementtests",
"dynamicsax-measurementtests-compile",
"dynamicsax-measurementtests-develop",
"dynamicsax-measurementtests-formadaptor",
"dynamicsax-meta-application-development",
"dynamicsax-meta-application-runtime",
"dynamicsax-meta-businessappplatform-development",
"dynamicsax-meta-businessappplatform-runtime",
"dynamicsax-meta-financialaccounting-development",
"dynamicsax-meta-financialaccounting-runtime",
"dynamicsax-meta-onebox-app-development",
"dynamicsax-meta-onebox-app-runtime",
"dynamicsax-meta-onebox-financialaccounting-development",
"dynamicsax-meta-onebox-financialaccounting-runtime",
"dynamicsax-meta-onebox-platform-development",
"dynamicsax-meta-onebox-platform-runtime",
"dynamicsax-meta-platform-development",
"dynamicsax-meta-platform-runtime",
"dynamicsax-OrchestrationPlugins",
"dynamicsax-organization-compile",
"dynamicsax-organization-develop",
"dynamicsax-organizationformadaptor",
"dynamicsax-organization-formadaptor",
"dynamicsax-organizationformadaptor-compile",
"dynamicsax-organizationformadaptor-develop",
"dynamicsax-organizationformadaptor-formadaptor",
"dynamicsax-organizationtests",
"dynamicsax-organizationtests-compile",
"dynamicsax-organizationtests-develop",
"dynamicsax-organizationtests-formadaptor",
"dynamicsax-payroll-compile",
"dynamicsax-payroll-develop",
"dynamicsax-payrollformadaptor",
"dynamicsax-payroll-formadaptor",
"dynamicsax-payrollformadaptor-compile",
"dynamicsax-payrollformadaptor-develop",
"dynamicsax-payrollformadaptor-formadaptor",
"dynamicsax-payrolltests",
"dynamicsax-payrolltests-compile",
"dynamicsax-payrolltests-develop",
"dynamicsax-payrolltests-formadaptor",
"dynamicsax-performancetest",
"dynamicsax-performancetest-compile",
"dynamicsax-performancetest-develop",
"dynamicsax-performancetest-formadaptor",
"dynamicsax-performancetool",
"dynamicsax-performancetool-compile",
"dynamicsax-performancetool-develop",
"dynamicsax-performancetool-formadaptor",
"dynamicsax-performancetoolunittests",
"dynamicsax-performancetoolunittests-compile",
"dynamicsax-performancetoolunittests-develop",
"dynamicsax-performancetoolunittests-formadaptor",
"dynamicsax-policy-compile",
"dynamicsax-policy-develop",
"dynamicsax-policyformadaptor",
"dynamicsax-policy-formadaptor",
"dynamicsax-policyformadaptor-compile",
"dynamicsax-policyformadaptor-develop",
"dynamicsax-policyformadaptor-formadaptor",
"dynamicsax-policytests",
"dynamicsax-policytests-compile",
"dynamicsax-policytests-develop",
"dynamicsax-policytests-formadaptor",
"dynamicsax-primitivetest",
"dynamicsax-primitivetest-compile",
"dynamicsax-primitivetest-develop",
"dynamicsax-primitivetest-formadaptor",
"dynamicsax-productconfiguration",
"dynamicsax-publicsector-compile",
"dynamicsax-publicsector-develop",
"dynamicsax-publicsectorformadaptor",
"dynamicsax-publicsector-formadaptor",
"dynamicsax-publicsectorformadaptor-compile",
"dynamicsax-publicsectorformadaptor-develop",
"dynamicsax-publicsectorformadaptor-formadaptor",
"dynamicsax-publicsectortests",
"dynamicsax-publicsectortests-compile",
"dynamicsax-publicsectortests-develop",
"dynamicsax-publicsectortests-formadaptor",
"dynamicsax-retailtests",
"dynamicsax-retailtests-compile",
"dynamicsax-retailtests-develop",
"dynamicsax-retailtests-formadaptor",
"dynamicsax-scmtests",
"dynamicsax-scmtests-compile",
"dynamicsax-scmtests-develop",
"dynamicsax-scmtests-formadaptor",
"dynamicsax-scmteststaging",
"dynamicsax-scmteststaging-compile",
"dynamicsax-scmteststaging-develop",
"dynamicsax-scmteststaging-formadaptor",
"dynamicsax-servertests",
"dynamicsax-servertests-compile",
"dynamicsax-servertests-develop",
"dynamicsax-servertests-formadaptor",
"dynamicsax-sitests",
"dynamicsax-sitests-compile",
"dynamicsax-sitests-develop",
"dynamicsax-sitests-formadaptor",
"dynamicsax-sourcedocumentation-compile",
"dynamicsax-sourcedocumentation-develop",
"dynamicsax-sourcedocumentationformadaptor",
"dynamicsax-sourcedocumentation-formadaptor",
"dynamicsax-sourcedocumentationformadaptor-compile",
"dynamicsax-sourcedocumentationformadaptor-develop",
"dynamicsax-sourcedocumentationformadaptor-formadaptor",
"dynamicsax-sourcedocumentationtypes-compile",
"dynamicsax-sourcedocumentationtypes-develop",
"dynamicsax-sourcedocumentationtypes-formadaptor",
"dynamicsax-sourcedocumentationtests",
"dynamicsax-sourcedocumentationtests-compile",
"dynamicsax-sourcedocumentationtests-develop",
"dynamicsax-sourcedocumentationtests-formadaptor",
"dynamicsax-subledger-compile",
"dynamicsax-subledger-develop",
"dynamicsax-subledgerformadaptor",
"dynamicsax-subledger-formadaptor",
"dynamicsax-subledgerformadaptor-compile",
"dynamicsax-subledgerformadaptor-develop",
"dynamicsax-subledgerformadaptor-formadaptor",
"dynamicsax-sysfake",
"dynamicsax-sysfake-compile",
"dynamicsax-sysfake-develop",
"dynamicsax-sysfake-formadaptor",
"dynamicsax-tax-compile",
"dynamicsax-tax-develop",
"dynamicsax-taxformadaptor",
"dynamicsax-tax-formadaptor",
"dynamicsax-taxformadaptor-compile",
"dynamicsax-taxformadaptor-develop",
"dynamicsax-taxformadaptor-formadaptor",
"dynamicsax-test",
"dynamicsax-test-compile",
"dynamicsax-test-develop",
"dynamicsax-testessentials-compile",
"dynamicsax-testessentials-develop",
"dynamicsax-testessentials-formadaptor",
"dynamicsax-test-formadaptor",
"dynamicsax-tutorial-compile",
"dynamicsax-tutorial-develop",
"dynamicsax-tutorial-formadaptor",
"dynamicsax-unitofmeasure-compile",
"dynamicsax-unitofmeasure-develop",
"dynamicsax-unitofmeasure-formadaptor",
"dynamicsax-unitofmeasureformadaptor-compile",
"dynamicsax-unitofmeasureformadaptor-develop",
"dynamicsax-unitofmeasureformadaptor-formadaptor",
"dynamicsax-unittests",
"dynamicsax-unittests-compile",
"dynamicsax-unittests-develop",
"dynamicsax-unittests-formadaptor",
"dynamicsax-upgrade",
"dynamicsax-upgrade-compile",
"dynamicsax-upgrade-develop",
"dynamicsax-upgrade-formadaptor")

$sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
$files=get-childitem -Path:$sourcePath *.nupkg
foreach ($file in $files) 
{
    $fileName =  ($file.BaseName).Split(".")[0]
    if ($blockListedPackage -contains "$fileName")
    {
        write-output "Removing $file from packaging folder"
        remove-item $file.FullName
    }
}

# SIG # Begin signature block
# MIInkwYJKoZIhvcNAQcCoIInhDCCJ4ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC8u6LYZSpJHT4/
# ga/LfkGNrpLG3Gc5/F+u7/pnwhnT3KCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXMwghlvAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIPcTRSXWxELwHSROfVGlyFii
# 8+X1xMgxaUgMAl9E/lH+MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEANKD3TZm9vZRgap3XBl7npWFgn3HazsP0TlwF9kZcqGo7wMuQo8U9mxET
# +kUR7gXWQ/OkkZheBTEANOq+DW8JBwjuzI/CIs5Zqx7K2zhhaTVvHs2yyuZcq9cw
# mFmExDb5cOrAuCR7iTx4hozXgPRp1cFnhoO7/hHBAV7brXwTVUwtr8sDasUxK8rc
# dENFrQZjvMPnd1YvgV5KDrG5ZfrXUqf53DipVgUo15eRq3z09PU3dpYYNM9Q7px0
# YAdvNOAKrIbhW1h1PnZa3imSc5GFoAm20YRKYJo3Qg96VaUWZHYCbb3CIuWgdw/Q
# HmVGO7HQMH2fF6/vMUQfvYtk4nM2v6GCFv0wghb5BgorBgEEAYI3AwMBMYIW6TCC
# FuUGCSqGSIb3DQEHAqCCFtYwghbSAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCiUExVK0hm/vMiKD/ynke7R+VqRrS2Ma/k/y6SR0yqUgIGZDfpJQCr
# GBMyMDIzMDQyNzE5NDYwMi44MjdaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpFNUE2LUUy
# N0MtNTkyRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# EVQwggcMMIIE9KADAgECAhMzAAABvvQgou6W1iDWAAEAAAG+MA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIyMTEwNDE5MDEy
# MloXDTI0MDIwMjE5MDEyMlowgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkU1QTYtRTI3Qy01OTJFMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEF
# AAOCAg8AMIICCgKCAgEApV/y2z7Da7nMu0tykLY8olh7Z03EqFNz3iFlMp9gOfVm
# ZABmheCc87RuPdQ2P+OHUJiqCQAWNuNSoI/Q1ixEw9AA657ldD8Z3/EktpmxKHHa
# vOhwQSFPcpTGFVXIxKCwoO824giyHPG84dfhdi6WU7f7D+85LaPB0dOsPHKKMGlC
# 9p66Lv9yQzvAhZGFmFhlusCy/egrz6JX/OHOT9qCwughrL0IPf47ULe1pQSEEihy
# 438JwS+rZU4AVyvQczlMC26XsTuDPgEQKlzx9ru7EvNV99l/KCU9bbFf5SnkN1mo
# UgKUq09NWlKxzLGEvhke2QNMopn86Jh1fl/PVevN/xrZSpV23rM4lB7lh7XSsCPe
# FslTYojKN2ioOC6p3By7kEmvZCh6rAsPKsARJISdzKQCMq+mqDuiP6mr/LvuWKin
# P+2ZGmK/C1/skvlTjtIehu50yoXNDlh1CN9B3QLglQY+UCBEqJog/BxAn3pWdR01
# o/66XIacgXI/d0wG2/x0OtbjEGAkacfQlmw0bDc02dhQFki/1Q9Vbwh4kC7VgAiJ
# A8bC5zEIYWHNU7C+He69B4/2dZpRjgd5pEpHbF9OYiAf7s5MnYEnHN/5o/bGO0aj
# Ab7VI4f9av62sC6xvhKTB5R4lhxEMWF0z4v7BQ5CHyMNkL+oTnzJLqnLVdXnuM0C
# AwEAAaOCATYwggEyMB0GA1UdDgQWBBTrKiAWoYRBoPGtbwvbhhX6a2+iqjAfBgNV
# HSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5o
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBU
# aW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwG
# CCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRz
# L01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNV
# HRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IC
# AQDHlfu9c0ImhdBis1yj56bBvOSyGpC/rSSty+1F49Tf6fmFEeqxhwTTHVHOeIRN
# d8gcDLSz0d79mXCqq8ynq6gJgy2u4LyyAr2LmwzFVuuxoGVR8YuUnRtvsDH5J+un
# ye/nMkwHiC+G82h3uQ8fcGj+2H0nKPmUpUtfQruMUXvzLjV5NyRjDiCL5c/f5ecm
# z01dnpnCvE6kIz/FTpkvOeVJk22I2akFZhPz24D6OT6KkTtwBRpSEHDYqCQ4cZ+7
# SXx7jzzd7b+0p9vDboqCy7SwWgKpGQG+wVbKrTm4hKkZDzcdAEgYqehXz78G00mY
# ILiDTyUikwQpoZ7am9pA6BdTPY+o1v6CRzcneIOnJYanHWz0R+KER/ZRFtLCyBMv
# LzSHEn0sR0+0kLklncKjGdA1YA42zOb611UeIGytZ9VhNwn4ws5GJ6n6PJmMPO+y
# PEkOy2f8OBiuhaqlipiWhzGtt5UsC0geG0sW9qwa4QAW1sQWIrhSl24MOOVwNl/A
# m9/ZqvLRWr1x4nupeR8G7+DNyn4MTg28yFZRU1ktSvyBMUSvN2K99BO6p1gSx/wv
# SsR45dG33PDG5fKqHOgDxctjBU5bX49eJqjNL7S/UndLF7S0OWL9mdk/jPVHP2I6
# XtN0K4VjdRwvIgr3jNib3GZyGJnORp/ZMbY2Dv1mKcx7dTCCB3EwggVZoAMCAQIC
# EzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBS
# b290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoX
# DTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIi
# MA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC
# 0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VG
# Iwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP
# 2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/P
# XfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361
# VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwB
# Sru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9
# X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269e
# wvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDw
# wvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr
# 9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+e
# FnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAj
# BgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+n
# FV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEw
# PwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9j
# cy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAf
# BgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNS
# b29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0Nl
# ckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4Swf
# ZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTC
# j/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu
# 2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/
# GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3D
# YXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbO
# xnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqO
# Cb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I
# 6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0
# zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaM
# mdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNT
# TY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLLMIICNAIBATCB+KGB0KSBzTCByjEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWlj
# cm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBF
# U046RTVBNi1FMjdDLTU5MkUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAGitWlL3vPu8ENOAe+i2+4wfTMB7oIGD
# MIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEF
# BQACBQDn9NxRMCIYDzIwMjMwNDI3MTkzNDQxWhgPMjAyMzA0MjgxOTM0NDFaMHQw
# OgYKKwYBBAGEWQoEATEsMCowCgIFAOf03FECAQAwBwIBAAICHjQwBwIBAAICEZow
# CgIFAOf2LdECAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgC
# AQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQAYg3i+cCVyJQS3
# 9Yn5woMdm8b8Ndgatf2JIkvLwQr82EyY2jTtkZHfpeEliufoJcHEdUMzpYxxYY1n
# SPflx8mHy1Hc2T/Qi21YwkeAPxZaAgG1C3gkOGA5MnDlfZxOvRhLYJjmt+joVyBi
# sGTkoEpiHfOB7rYB9dwKqvtLmGBt0jGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABvvQgou6W1iDWAAEAAAG+MA0GCWCGSAFl
# AwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcN
# AQkEMSIEIJwiJgqFqmtZop+Jm+Is3BGshlEugL0beTIQpTO/H5zzMIH6BgsqhkiG
# 9w0BCRACLzGB6jCB5zCB5DCBvQQglO6Kr632/Oy9ZbXPrhEPidNAg/Fef7K3SZg+
# DxjhDC8wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# Ab70IKLultYg1gABAAABvjAiBCDpL+IwzMts72jok8mg7dYb9B8ofKTDNfsrcwHS
# B8hYnTANBgkqhkiG9w0BAQsFAASCAgCAFgsncQ4I9QAglH6YAWDwTbSKtxjzNqLc
# Bim/794AjBRtKDB8HZvt96t3jlc/uFOE6lZH6IQeRJoBhRPtWO+yuMyIQB8mfIbS
# d9yBTt87pNNkuvGJC1F93USoUd9cWY1VETnHwicUtqHrN0LcFZkVQZo9avFwrZrS
# 1H1jykOPAmuhbkmWPfGkZkDts2IB57OQhL63R9RBYBOGMaJMM4Oc3r8T4RKvChZm
# uLAJZBgcB9Mg9nbwC26P2xNhMTYo59gk0mxpxy8sIVN2tIhtEQ/ZqrDiC/gySnIy
# HEnL2FmzeuDxe/yYNN8G5Azig881yn9QPjNwrwJdrJiSt5AQ4XY82EaFBFkhEqAC
# DKszfM61cYm1bJaWI4MeyxdMHXjopgCz+gW99SMzIaT9G9z+90pQ2IIV4Ih1oUyr
# PdklPTJJQaoDDx+LX1q4eLC+E73xE0eGUx+y0Eo/xX1BT7imRHsW0XpDanrpej8M
# xHDcSdGTetBAZa8Y+Nv1i7ryhezhfRROZLGP/pgA5QW9sN+LmofNuWjBGIxstatz
# 1R5aQJaQ9t4PFduuGfhOkuCm+F3mejFoSslgFSPd1FNxuEYvZqkU+vaDuLYVtXAv
# bvNxZZd3SHP+by2RTMojhG1qwEHLO/CKuERTU8/rm5f5OozMylKthGuRfGqv1bUN
# oJrRk09Dag==
# SIG # End signature block
