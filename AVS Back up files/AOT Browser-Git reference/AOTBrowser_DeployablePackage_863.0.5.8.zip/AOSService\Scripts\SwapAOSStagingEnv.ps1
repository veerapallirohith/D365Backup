﻿<#
.SYNOPSIS
    Swap the AOS staging environment to production.

.DESCRIPTION

    Copyright © 2019 Microsoft. All rights reserved.
#>
[CmdletBinding()]
param
(
    [Parameter(Mandatory = $false, HelpMessage = "The path to the directory in which to write log files.")]
    [string]$LogDir,
    [Parameter(Mandatory = $false, HelpMessage = "The ID of the runbook this is executing as part of.")]
    [string]$RunbookId
)

$ErrorActionPreference = "Stop"
Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1" -Force -DisableNameChecking

# Initialize the log file to use with Write-ServicingLog.
Set-ServicingLog -LogDir $LogDir

# Initialize exit code.
[int]$ExitCode = 0

# Get the runbook ID
if ([string]::IsNullOrWhiteSpace($RunbookId))
{
    $RunbookId = Get-RunbookId

    #If the runbook ID still wasn't found, set it to a unique value
    if ([string]::IsNullOrWhiteSpace($RunbookId))
    {
        $runbookIdPlaceholder = [DateTime]::UtcNow.Ticks.ToString()
        Write-ServicingLog "Warning: Runbook ID was not specified and could not be determined. Using [$runbookIdPlaceholder] as a temporary Runbook ID."
        $RunbookId = $runbookIdPlaceholder
    }
}

# Progress breadcrumb names
$createStagingCompleted = "CreateAOSStagingEnvCompleted"
$swapStagingStarted = "SwapAOSStagingEnvStarted"
$swapStagingCompleted = "SwapAOSStagingEnvCompleted"

try
{
    <#
        Directories used in this script:
        - <service volume>\AOSServiceStaging
            The initial staging directory pre-swap
        - <service volume>\AOSServiceBackup
            The post-swap backup of the original AOSService folder
        - <service volume>\AOSService
            The current AOSService instance
        - <deployable package root>\RunbookWorkingFolder\<runbook id>\<machine>\AOSService\<step>\Backup\AOSServiceBackup
            The backup location on completion of SwapAOSStagingEnv.ps1
    #>

    Write-ServicingLog "Starting AOS swap staging environment script..."

    # If Copy Staging Folder task is not disabled, the content of AOSServiceStaging folder may not exactly match the AOSService folder
    Assert-CopyStagingTaskNotRunning

    $aosWebServicePath = Get-AosServicePath
    $stagingFolder = Get-AosServiceStagingPath
    $backupFolder = Get-AosServiceBackupPath

    #region Initialize script progress tracking
    $progressFileName = "AOSStagingProgress_$($RunbookId).json"
    $progressFileInitial = Join-Path -Path $stagingFolder -ChildPath $progressFileName
    $progressFilePostSwap = Join-Path -Path $aosWebServicePath -ChildPath $progressFileName

    if (Test-Path $progressFilePostSwap)
    {
        # The swap completed so the progress file from the initial creation of AOSServiceStaging should now be in AOSService
        Initialize-ScriptProgress -progressFile $progressFilePostSwap -ErrorAction Continue
    }
    elseif (Test-Path $progressFileInitial)
    {
        # The swap was not started or incomplete so the progress file should still exist in AOSServiceStaging
        Initialize-ScriptProgress -progressFile $progressFileInitial -ErrorAction Continue
    }
    else
    {
        # Not in the expected location. Log warning - this fails later on when checking for successful completion of the staging directory.
        Write-ServicingLog "Warning: unable to detect AOSService staging progress file [$progressFileName] for staging creation."   
    }
    #endregion

    if (Test-Path -Path $stagingFolder)
    {
        # Check that creation of the staging folder completed successfully.
        Write-ServicingLog "Checking for successful AOS staging environment creation..."
        if (Test-ScriptProgress $createStagingCompleted)
        {
            Write-ServicingLog "Detected successful creation of the AOS Staging environment at [$(Get-ScriptProgress $createStagingCompleted)] for runbook [$RunbookId]"
        }
        else 
        {
            # Log warning if the completion breadcrumb was not found 
            # Leave it to the parent runbook to fail on unfulfilled step dependencies
            Write-ServicingLog "Warning: No completion detected for pre-req step CreateAOSStagingEnv."
        }

        Add-ScriptProgress $swapStagingStarted -ErrorAction Continue

        Write-ServicingLog "Terminating watchdog process if running."
        KillWatchdogProcess

        # Ensure AOS service is stopped.
        # This is a mitigation in case the machine was rebooted or the AOS service started while deployable package.
        Write-ServicingLog "Calling script to stop the AOS..."
        & "$PSScriptRoot\AutoStopAOS.ps1"

        Write-ServicingLog "Terminating other user sessions..."
        KillAllOtherUserSession

        Write-ServicingLog "Terminating processes locking files under AOS service folder..."
        KillProcessLockingFolder -folder $aosWebServicePath

        Write-ServicingLog "Terminating watchdog process if running."
        KillWatchdogProcess

        if (Test-Path -Path $aosWebServicePath)
        {
            if (Test-Path -Path $backupFolder)
            {
                Write-ServicingLog "Removing existing $($backupFolder) backup folder..."
                Get-ChildItem -Path $backupFolder -Recurse | Remove-Item -Force -Recurse
                Remove-Item -Path $backupFolder -Force
            }

            Write-ServicingLog "Renaming $($aosWebServicePath) to AosServiceBackup..."
            Rename-Item -Path $aosWebServicePath -NewName "AosServiceBackup"
        }

        Write-ServicingLog "Renaming $($stagingFolder) to AosService..."
        Rename-Item -Path $stagingFolder -NewName "AosService"

        # $RunbookBackupFolder and $PSScriptRoot variables are populated directly from runbook.
        $DPBackupFolder = "$RunbookBackupFolder"

        if ([string]::IsNullOrEmpty($DPBackupFolder))
        {
            $DPBackupFolder = Join-Path -Path $PSScriptRoot -ChildPath "ManualAosServiceBackup"
        }

        Write-ServicingLog "Moving $($backupFolder) to $($DPBackupFolder)..."
        Move-Item -Path $backupFolder -Destination $DPBackupFolder -Force

        # Generate installation records.
        Write-ServicingLog "Generating installation records..."
        GenerateMetadataModuleInstallationInfo

        # If the script executed this far, the progress file is now in the swapped location. 
        # Re-initialize progres tracking to the swapped location and write completion.
        Initialize-ScriptProgress -progressFile $progressFilePostSwap -ErrorAction Continue
        Add-ScriptProgress $swapStagingCompleted -ErrorAction Continue
    }
    elseif (Test-ScriptProgress $swapStagingCompleted -ErrorAction SilentlyContinue)
    {
        Write-ServicingLog "Detected staging swap completed at [$(Get-ScriptProgress -ProgressStep $swapStagingCompleted)] for runbook [$($RunbookId)]"
    }
    else
    {
        Write-ServicingLog "Warning: No staging folder found at: $stagingFolder"
    }

    # Ensure that a log path exists.
    [string]$logPath = $LogDir
    if ([String]::IsNullOrWhiteSpace($logPath))
    {
        $logPath = "$PSScriptRoot"
    }

    #region Change IIS Ping Interval on config change
    if (Test-Path -Path "$PSScriptRoot\ChangeIISPingInterval.ps1")
    {
        $dt = [System.DateTime]::Now.ToString("yyyyMMddHHmmss");
        $logFile = Join-Path -Path $logPath -ChildPath "ChangeIISPingInterval.$dt.log"
        Write-ServicingLog "Change IIS Ping Interval..."
        Invoke-Expression "$PSScriptRoot\ChangeIISPingInterval.ps1 -log:`"$logFile`" -appPoolName:$(Get-AosAppPoolName)"
    }
    #endregion

    #region Disable IIS restart on config change
    if (Test-Path -Path "$PSScriptRoot\SetIISDisallowRotationOnConfigChange.ps1")
    {
        $dt = [System.DateTime]::Now.ToString("yyyyMMddHHmmss");
        $logFile = Join-Path -Path $logPath -ChildPath "SetIISDisallowRotationOnConfigChange.$dt.log"
        Write-ServicingLog "Disabling rotation on config change..."
        Invoke-Expression "$PSScriptRoot\SetIISDisallowRotationOnConfigChange.ps1 -log:`"$logFile`" -appPoolName:$(Get-AosAppPoolName) -disallowRotationOnConfigChangeValue:$true"
    }
    #endregion
}
catch
{
    # Ensure non-zero exit code if an exception is caught and no exit code set.
    if ($ExitCode -eq 0)
    {
        $ExitCode = 1024
    }

    $ErrorMessage = "Error during AOS swap staging: $($_)"

    Write-ServicingLog $ErrorMessage
    Write-ServicingLog $($_) -Vrb
    Write-ServicingLog "AOS swap staging environment script failed with exit code: $($ExitCode)."

    # Use throw to indicate error to AXUpdateInstaller.
    # In case of exceptions, the output is not captured, so only the error message and
    # log file contents will be available for diagnostics.
    throw "$($ErrorMessage) [Log: $(Get-ServicingLog)]"
}
finally
{
    # Back up the progress file for this script's execution.
    $backupDir = if ([string]::IsNullOrEmpty($LogDir)) { $PSScriptRoot } else { $LogDir }
    $logTimeSuffix = [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')
    $scriptProgressFileBackup = Join-Path -Path $backupDir -ChildPath "SwapAOSStagingEnv-ProgressBackup-$logTimeSuffix.json"
    Copy-ScriptProgressFile -Destination $scriptProgressFileBackup -ErrorAction Continue
    
    Write-ServicingLog "Attempting to reset IIS"
    Reset-IIS
    
    if($?)
    {
        Write-ServicingLog "Successfully reset IIS"
    }
}

Write-ServicingLog "AOS swap staging environment script completed with exit code: $($ExitCode)."
exit $ExitCode
# SIG # Begin signature block
# MIInkwYJKoZIhvcNAQcCoIInhDCCJ4ACAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAtS2vLNQBZhCok
# pk+5G0vxYkh4u8Ga+aGTZlmcXCf9D6CCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXMwghlvAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOe5WD6okbFHciCY7W/mekKb
# 0LuOcxP6ZChClw8G8t5UMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAMzX+ZG8KY5boZuR8fME9BgV97+J33GLvRHwzHjdnWc/TqKoM+ViVJ5Dw
# V13cg1eFd5uztG+YJSrJn8Bpy5ekg2kWFcsbsTUonQu+gS2JpsfAMHh1FD/c4Upg
# +KFZuZ4CxJm+5aVv5DvlwnEBgKlGcUC6QiUyRz7kNlzrJy1yu7l4TwRhU9I+CXfT
# 1jdYppy3h/5uMhO8e2H7qdiucp1E0WlIlsMeENms5lrTddvwqPNcQ90E0oBA2kaw
# 24Pb499cKcd2pxmwq7GJQV6hJWmI7o0JG8R4BJ2Om1Oh06427bDgz0D0YJn+FQvY
# vC1c/7MwKcb7wRNJx0EmUqK3EfroJaGCFv0wghb5BgorBgEEAYI3AwMBMYIW6TCC
# FuUGCSqGSIb3DQEHAqCCFtYwghbSAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBpyU1Nbkx+DiSMSywFkEiovSkzMEgQSXtNd39qmQrHKwIGZDfpldLi
# GBMyMDIzMDQyNzE5NDYwMi41NDdaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1l
# cmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpFQUNFLUUz
# MTYtQzkxRDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# EVQwggcMMIIE9KADAgECAhMzAAABw4tv00i/DpFdAAEAAAHDMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIyMTEwNDE5MDEy
# OVoXDTI0MDIwMjE5MDEyOVowgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkVBQ0UtRTMxNi1DOTFEMSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEF
# AAOCAg8AMIICCgKCAgEAu+u86s3R/q+ikos80aD42Ym21NDOZtldNRxMFUxm4o9k
# VWkSh2c8jOCxJXwV2KFodCTxpGQs9jy5nUI+Lq/bt0HWtSYPMPPtet420gzwM1Es
# R26kbpwlBHxFY4hk3y3AH+1YKf9bhvPs7kPbXbH7gdaciteB+F7FoORt9e0D/dsB
# eG80GZAF2y6LWAj6C2mMqlafXkwbfTyQanuX65Yu+xMpyJ1fAREpuR766rePrqlE
# 0KaaeD0nqOgGrTkSZeCMDPH6OtJ00jXMwbIDyH7l4fYReIsTfzN5Gf3Uairsjea+
# KFy22lU8elnIXjoeyx3pcesH+q5arY1c6HPfeSnkeMok/gxnB7P1Mjt7I9EI9thQ
# tMvy/1SUmLG12rBR/DfheE/VJpcm/TYeoV11NfQQnl/jBbPbSRBp0HGqTIcWDpY6
# MgSdBoQET1DvpE4PX4sndNGc1wGyg45pH62ZMfUF/CzGZ7iV637RtnQFXDzTxoSE
# EkdXMdWDJG+jjxoC16lRk1xFnfkA4uoma4mKso7qvE6d27+K6yzISWQ7TjutYLKJ
# nSzNvfiNiuyv/0xxCASSARvOQ3v9cegvM/pnuU9c6s+4gmK3+5jhcvnWGQqJE0tp
# YHmk3bmmBL1gHm9TjBJz5m/8rvHM3Rw3OUhV4/wmAL32KmPR5Ubb4ww5HNGiuY0C
# AwEAAaOCATYwggEyMB0GA1UdDgQWBBQcGL7N2NdvAaK8TcLrxMTsa8aB1jAfBgNV
# HSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5o
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBU
# aW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwG
# CCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRz
# L01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNV
# HRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IC
# AQDd8qZbHBqdBFRDxGGwDollnRyd0WmUnjqoP+5QCH4vMPBt4umHVhJuyeRkDELk
# TWZuWqK3U1z2HnGatbnETcHUlywlH+3I7R7fU0zKYw2PLA+VawCcrnsICgE3242E
# sEC/Z0YU740NJ/xbuzrGtTEtUIiQvr2ACPJyhsPote8ItTf4uNW4Mbo1QP0tjcBK
# CgEezIC4DYUM0BYCWCmeZmNwAlxfpTliOFEKB9UaSqHSs51cH8JY0gqL3LwI9LYf
# jEO77++HY/nMqXCMi9ihUKoIp2Tfjfzdm5Ng5V+yw8+wXl29RcW4Q4CvHntNfKxT
# 9oQ3J7YBQQEHWJPg8TNR9w4B82FzmrDd8sL6ETvGux5hFcwmF+Q2rT5Ma8dYUSdC
# Sg/ihoEYUGJZnZL9nyDp1snflSVX7FpLyALzDDlHBW1CJhYVffJRoqz1D4kRooqR
# BNRaMFMPingywwbEghMheJKNoda7AGgq+1HH1afRlE+9qYW9FKMezxeQmf8gcuAu
# hr9IAXyaF9DF0PJ5f4uhzOSvIC1BkJtzF6op45UYaI7V+9X8dcwXbZJnIIAH1cjV
# O8KEChxKIkpk4Qgy0PocgUwaGWqmLWRu1hQ1WJWnQXvvBYeYDGWbj/PtSlywv6m8
# mujLepfMvJcU25KWklSP2FuNx6aOVfeje+pgbwIQIVQ1nTCCB3EwggVZoAMCAQIC
# EzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBS
# b290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4MjIyNVoX
# DTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggIi
# MA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvXJHm9DtWC
# 0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa/rg2Z4VG
# Iwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AKOG6N7dcP
# 2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rboYiXcag/P
# XfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIckw+DJj361
# VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbnijYjklqwB
# Sru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F37ZyL9t9
# X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZfD9M269e
# wvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIzGHLXpyDw
# wvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR/bLUHMVr
# 9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1Hode2o+e
# FnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUCAwEAATAj
# BgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0OBBYEFJ+n
# FV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yDfQEBMEEw
# PwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvRG9j
# cy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAf
# BgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNS
# b29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0Nl
# ckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9/Cqt4Swf
# ZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5bbsPMeTC
# j/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvfam++Kctu
# 2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn0CS9QKC/
# GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlSdYo2wh3D
# YXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0j/aRAfbO
# xnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5JL5zbcqO
# Cb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakURR6nxt67I
# 6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4O+S3Fb+0
# zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVnK+ANuOaM
# mdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoIYn/ZcGNT
# TY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLLMIICNAIBATCB+KGB0KSBzTCByjEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWlj
# cm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBF
# U046RUFDRS1FMzE2LUM5MUQxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAPEdL+Ps+h03e+SLXdGzuY7tLu7OoIGD
# MIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEF
# BQACBQDn9NyNMCIYDzIwMjMwNDI3MTkzNTQxWhgPMjAyMzA0MjgxOTM1NDFaMHQw
# OgYKKwYBBAGEWQoEATEsMCowCgIFAOf03I0CAQAwBwIBAAICCFkwBwIBAAICEsww
# CgIFAOf2Lg0CAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgC
# AQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQB9CEWSCbqoWX2+
# R44HVEfj9DvsdhtxkteSVcs1IFSkeKwgR4NwDn9dtvtF0feYEhLfegl7uVJWfI3s
# gXv+z9a/kmx6ykPtYQKtKSI7Xs4VYyPkg14j1ja5wEAuke7cG6XTKB8h8BSAxQFw
# pbJSQN1G06RTYGg/6AqwYF0U0l8R2DGCBA0wggQJAgEBMIGTMHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABw4tv00i/DpFdAAEAAAHDMA0GCWCGSAFl
# AwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcN
# AQkEMSIEIGKc1axhYEOQ/n2KcnoczsGwGZnEBZfmQS/Wr4mJQ3m0MIH6BgsqhkiG
# 9w0BCRACLzGB6jCB5zCB5DCBvQQg0vtTm2+SSerh1KiAkwrJTALxTfJotlPcDZ2Z
# Sn78KkkwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AcOLb9NIvw6RXQABAAABwzAiBCCeDHluE7gHA3UWfF1wh5ja1Gk1G3H/uTxlBLs5
# G42v5DANBgkqhkiG9w0BAQsFAASCAgBlvtJ8o7rJ7tMRY01uicQxbM+fbVenGpFS
# p98oKtqU/4FbZHQdvYaUaa6xhwa4PDx4bv6H86w/0YPn6IoLfZIwMrKam8uIbr4Y
# 6IEV0kWuyhwgSFM1YaIKfHnQJUdNCtAambK2NwLfj02iVKlt7ZBRQBy1tLAdkmdN
# gr4K+2hljsfZ+pYaKw++59gjyukpIcZl05eFhZT+9AnQJRDUKiJajGXyaRYeJ9hA
# El6V7oLrlIdD/fcqDwmp/+5aLdV28yF0vESoiIwm+fGrk54Bpm6G2r6lB2b33MmW
# t0EqjzkLV/KS2evICRRk4+tPpWEiKGV7I4AM4xBDKaK0GpBDZ1UqppwGC9DtKASU
# O0bS0jON0ewej88W6wD/z2xhxbg01xjpnKZ5ZWoYeBP2piNBOqBBiatuzuN7bu6S
# Rcnqm4pmDcTlxM71qrRZAGp2/vh5m9+wJRLlB+egPbs0YiGQ1Og0wzHxGwOqdL4x
# mTIhwGqaMPtnOvnLxPq9H2owOd5IZKcm70egnx3vlGS4A/Yu3pmDpcGonhlNvvnV
# aUpjUn7lqq3kCCS0Nvz+Ui/Xpy20shXB8z4SSj+XYAAvvXPiQEQB8khNJDykhQep
# SkEVNx4XC9ffv6yMxsvf/3xoXifdPwnYLuJY+/pMGmjXpYhBD6b9WossbUskCPnM
# Twk15W7u6g==
# SIG # End signature block
